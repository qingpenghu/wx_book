
const tokens = {
  developer: { // 开发人员-超级管理员
    token: 'developer-token'
  },
  leader: { // 领导管理层(领导账号)
    token: 'leader-token'
  },
  manager: { // 管理员(普通管理员账号)
    token: 'manager-token'
  },
  clerk: { // 普通用户
    token: 'clerk-token'
  }
}

const users = {
  'developer-token': {
    roles: ['developer'],
    rolesName: '维护人员',
    introduction: '这是一位严谨的维护人员',
    avatar: 'https://www.shuanghuaai.com/skin/images/c760560649a9ada014ab1126cf83c6d7_origin.jpg',
    name: '老严谨'
  },
  'leader-token': {
    roles: ['leader'],
    rolesName: '省厅局长',
    introduction: '省厅列表，王局',
    avatar: 'https://www.shuanghuaai.com/skin/images/c760560649a9ada014ab1126cf83c6d7_origin.jpg',
    name: '王局长'
  },
  'manager-token': {
    roles: ['manager'],
    rolesName: '普通管理员',
    introduction: '组织、部门负责人',
    avatar: 'https://www.shuanghuaai.com/skin/images/c760560649a9ada014ab1126cf83c6d7_origin.jpg',
    name: '老王组长'
  },
  'clerk-token': {
    roles: ['clerk'],
    rolesName: '基层走访人员',
    introduction: '乡镇科员，张科',
    avatar: 'https://www.shuanghuaai.com/skin/images/8db3a8f5c1db8372fa554b33463c3336_origin.jpg',
    name: '张职员'
  }
}

export default [
  // user login
  {
    url: '/user/login',
    type: 'post',
    response: config => {
      const { username } = config.body
      const token = tokens[username]

      // mock error
      if (!token) {
        return {
          code: 60204,
          message: 'Account and password are incorrect.'
        }
      }

      console.log('[MOCK] 返回token', token)
      return {
        code: 200,
        data: token
      }
    }
  },

  // get user info
  {
    url: '/user/info\.*',
    type: 'get',
    response: config => {
      const { token } = config.query
      const info = users[token]

      // mock error
      if (!info) {
        return {
          code: 50008,
          message: 'Login failed, unable to get user details.'
        }
      }

      return {
        code: 200,
        data: info
      }
    }
  },

  // user logout
  {
    url: '/user/logout',
    type: 'post',
    response: _ => {
      return {
        code: 200,
        data: 'success'
      }
    }
  }
]
