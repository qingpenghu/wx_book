<template>
  <div class="index_content" ref="wrapper">
    <div class="index_content_main clear" >
      <!-- <div class="index_content_margin"></div> -->
      <van-loading type="spinner" color="black" v-show="loading" />
      <div class="carouser">
        <van-swipe :autoplay="3000">
          <van-swipe-item v-for="(item,index) in lunboList" :key="index">
            <img :src="item.img_url" @click='linkTo(item.redirect_url)'/>
          </van-swipe-item>
        </van-swipe>
      </div>
      <div class="hart_main">
      <van-cell value="心愿单" class="hart" :center="center" :border="border">
          <div slot="right-icon" class="hart_more"><router-link to='/hart'><span>查看更多</span><van-icon name="arrow" /></router-link></div>
        </van-cell>
        <div class="list" ref="hart">
          <ul class="clear">
            <li v-for="(item, index) in hartList" :key="index">
              <router-link :to="{path:'/goodDetail',query:{id:item.id}}">
                <img :src="item.image_url" />
                <div class="exchange">{{item.is_favorites >0 ? (Number(item.buy_percent) >= 1 ? "去兑换" : item.total_balance +'/'+ item.exchange_points ):'收藏'}}</div>
                <div class="icon_info icon_info_left" v-show="item.product_ad_attr == 1 ? ( item.product_num_status ? ( item.specialOfferFlag ? true:false ) :  true) : false">{{item.product_num_status ? ( item.specialOfferFlag ? "特价商品" : ''): '无货'}}</div>
                <div class="icon_info icon_info_right" v-show="item.product_ad_attr == 1 ? ( item.product_num_status ? ( item.tag ? true:false ) :  false) : ( item.tag ? true:false )">{{item.tag}}</div>
              </router-link>
            </li>
          </ul>
        </div>
      </div>
      <!-- </van-pull-refresh> -->
      <div class="hot_shop" v-show="hotList.length > 0 ? true:false">
      <van-cell value="热卖商品" class="hart" :center="center" :border="border">
        <div slot="right-icon" class="hart_more"><router-link to='/classify'><span>查看更多</span><van-icon name="arrow" /></router-link></div>
      </van-cell>
        <div class="hot_list">
          <HotShop :hot='hotList'/>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import BScroll from 'better-scroll'
import './index.less'
import { Toast } from 'vant'
import HotShop from './HotShop'
import banner1 from '@/assets/index/banner1.png'
import banner2 from '@/assets/index/banner2.png'
export default {
  name: 'Index',
  components: {
    HotShop
  },
  data () {
    return {
      lunboList: [{img_url:banner1}, {img_url:banner2}],
      isLoading: false,
      center: Boolean(true),
      border: Boolean(false),
      hotList: [],
      hartList:[],
      scroll:'',
      hartScroll:'',
      loading:false
    }
  },
  methods: {
    onRefresh () {
      this.isLoading = true
      this.getBannerData()
      // console.log("1111")
      // this.getHotData()
      // this.getHartData()
    },
    linkTo(imgUrl) {
      if(imgUrl) {
        window.location.href=imgUrl
      }
      
    },
    getHartData () {
      let that = this
      this.$store.dispatch('commonService',{"apid": 176,
        params: {
          pageSize: "3",
          pageNo: "1",
        }})
      .then((result) => {
        if( result.apidata.code == 1) {
          that.hartList = result.apidata.data.datas
          if( that.isLoading ) that.getHotData()
          // console.log(result.apidata.data)
        }else{
          Toast(result.apidata.message);
        }
      })
      .catch((error) => {
        console.log(error)
      })
    },
    getHotData () {
      let that = this
      this.$store.dispatch('commonService',{"apid": 199, // 196改为199
        params: {
          pageSize: "10",
          pageNo: "1",
          limitNum: '6'
        }})
      .then((result) => {
        if( result.apidata.code == 1) {
          that.hotList = result.apidata.data
          that.isLoading = false
          that.loading = false
          that.scroll.finishPullDown()
        }else{
          Toast(result.apidata.message);
        }
      })
      .catch((error) => {
        console.log(error)
      })
    },
    getBannerData () {
      let that = this
      this.$store.dispatch('commonService',{"apid": "218", params:{}})
      .then((result) => {
        // console.log(result)
        if( result.apidata.code == 1) {
          that.lunboList = result.apidata.data
          if( that.isLoading ) that.getHartData()
        }else{
          Toast(result.apidata.message);
        }
      })
      .catch((error) => {
        console.log(error)
      })
    }
  },
  created () {
    this.getBannerData()
    this.getHotData()
    this.getHartData()
  },
  mounted() {
  	const _this = this; 
    setTimeout(()=>{
      _this.scroll = new BScroll(_this.$refs.wrapper,{
        scrollY:true,
        // scrollX:false,
        scrollbar:false,
        click:true,
        bounceTime:500,
        pullDownRefresh:{
        	threshold: 60, // 当下拉到超过顶部 50px 时，触发 pullingDown 事件
          stop: 20 // 刷新数据的过程中，回弹停留在距离顶部还有 20px 的位置
        }
      });
      _this.scroll.on('pullingDown', () => {
          _this.isLoading = true
			    _this.loading = true
			    _this.getBannerData()
			      // 在刷新数据完成之后，调用 finishPullDown 方法，回弹到顶部
      })
      
      _this.hartScroll = new BScroll(_this.$refs.hart,{
        scrollX:true,
        scrollbar:false,
        click:true
      });
    },20)
   
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less'>

</style>
