<template>
  <div class="login" >
   <div class="header">
    <van-nav-bar title="登录"  left-arrow @click-left="routergo" right-text="注册" @click-right="onClickRight" />
   </div>
   <div class="phoneInput">
        <span class="icon"><img src="../../assets/phone1.png"></span>
        <input type="tel" maxlength='11' name="tel" v-on:input="phoneChange" v-model="telNum" placeholder="请输入手机号" value="" />
    </div>
    <div class="phoneInput pwdInput">
        <span class="icon"><img src="../../assets/pwd1.png"></span>
        <input type="password" maxlength='11' name="tel" v-model="password" placeholder="请输入密码" value="" />
    </div>
    <div class="goLogin">登录</div>
    <div class="loginBottom">
    	<div class="forget">忘记密码</div>
    	<div class="fastLogin">快捷登录</div>
    </div>
  </div>
</template>

<script>
import './login.css'
import { Toast } from 'vant'
export default {
  name: 'Login',
  data () {
    return {
      telNum:'',
      password:''
    }
  },
  methods: {
   onClickRight() {
   	console.log("111")
   },
   routergo(){
   	console.log("222")
   },
   phoneChange(){
   	console.log("333")
   }
  },
  created () {
 
  },
  mounted() {
  
  }
}
</script>
<style lang='less'>
.login{
   height: 100%;
   overflow: hidden;
   input::-webkit-input-placeholder{color: #595959}
   input:-moz-placeholder{color: #595959}
   input::-moz-placeholder{color: #595959}
   input:-ms-input-placeholde{color: #595959}
  .phoneInput{
  	width: 80%;
  	height: 0.8rem;
  	margin: 1.4rem auto 0.3rem;
  	border-bottom: 1px solid #dcdcdc;
  	.icon{
		width: .48rem;
		height: 100%;
		float: left;
		padding-top: 0.21rem;
		img{
		      float: left;
			width: 0.25rem;
			height: 0.38rem;
		}
  	}
  	input{
  	  float: left;
  	  width: 80%;
  	  height: 100%;
  	  font-size: 0.24rem;
  	  border:none;
  	  color: #595959;
  	}
  }
  .pwdInput{
  	margin-top: 0;
  	margin-bottom: 0.5rem;
  }
  .goLogin{
  	width: 80%;
  	height: 0.8rem;
  	margin: 0 auto;
      background: #f66e6e;
      border-radius: 0.4rem;
      font-size: 0.3rem;
      text-align: center;
      padding-top: 0.2rem;
      letter-spacing: 0.1rem;
      color: #fff;
  }
  .loginBottom{
  	width: 80%;
  	height: 0.6rem;
  	margin: 0.15rem auto 0;
  	font-size: 0.25rem;
  	color: #b5b5b5;
  	.forget{
  		width: 40%;
  		height: 100%;
  		line-height: 0.6rem;
  		float: left;
  		text-align: left;
  	}
  	.fastLogin{
  		width: 40%;
  		height: 100%;
  		float: right;
  		text-align: right;
  		line-height: 0.6rem;
  	}
  	/*background: #666;*/
  }
}

</style>
