<template>
  <div class="Register" >
    <div class="header">
      <van-nav-bar title="注册"  left-arrow @click-left="routergo" right-text="登录" @click-right="toLogin" />
    </div>
    <div class="register_area">
      <ul>
        <li>
          <img src="../../assets/phone.png">
          <input type="tel" maxlength='11' name="tel" v-on:input="phoneChange"  v-model="telNum" placeholder="请输入手机号" value="" />
        </li>
        <li>
          <img src="../../assets/phone.png">
          <input type="number" maxlength='6' name="code"  v-model="code" placeholder="请输入验证码" class="codeInput" value="" />
          <button class="sendCode">发送验证码</button>
        </li>
        <li>
          <img src="../../assets/phone.png">
          <input type="text" maxlength='16' minLength='6' name="pass"  v-model="password" placeholder="请输入密码（6-16位数字，字母组合）" value="" />
        </li>
      </ul>
      <button class="toRegister">注 册</button>
    </div>
  </div>
</template>

<script>
import { Toast } from 'vant'
export default {
  name: 'Register',
  data () {
    return {
      telNum:'',
      code:'',  
      password:'',
      tips:''
    }
  },
  methods: {
    phoneChange: function() {
      this.tips = '';
      if(this.telNum.length == 11 && this.phoneCheck()){   // 长度达到11位
          this.ifRegister();
          this.getCodeAllow = true;
      }else{
          this.getCodeAllow = false;
          this.registerAllow = false;
      }
    },
    getCode () {  //获取验证码

    },
    getCode () {  //判断是否有注册过
    
    },
    phoneCheck: function() {
      const regExp = /^1(3|4|5|7|8|6|9)\d{9}$/;
      if(!this.telNum){
          this.tips = '请输入手机号'
          return false
      }else{
        if(!regExp.test(this.telNum)){
          this.tips = '请输入正确的手机号'
          return false
        }
        return true;
      }
    },
    toLogin() {  //去登录页面

    },
    routergo() { //跳转上一页

    }
  },
  created () {
 
  },
  mounted() {
  
  }
}
</script>
<style lang='less'>
  input,button{outline:none}
  input{
    -webkit-user-drag: text;
    -webkit-user-select: text;
    -moz-user-select: text;
    -ms-user-select: text;
    user-select: text;
  }
  input::-webkit-input-placeholder{color: #dcdcdc}
  input:-moz-placeholder{color: #fff}
  input::-moz-placeholder{color: #fff}
  input:-ms-input-placeholde{color: #fff}
  .Register{

    .header{
      height:0.748rem;
      width:100%;
      .van-nav-bar .van-icon{
        color: #282828;
      }
      .van-nav-bar__text{
        color:#dcdcdc;
      }
    }
    .register_area{
      width:6.3rem;
      margin:0 auto;
      ul{
        padding:0 .8rem;
        width:6.3rem;
        height:100%;
        margin-top:.6rem;
        li{
          width:100%;
          height:1.05rem;
          position:relative;
          padding-top:.5rem;
          padding-bottom:.2rem;
          border-bottom: .01rem solid #dcdcdc;
          img{
            width:.3rem;
            height:.36rem;
            position:absolute;
            left:0;
            bottom:.2rem
          }
          input{
            display:block;
            border:0;
            width: 100%;
            margin: 0 auto;
            color: #dcdcdc;
            font-size: .24rem;
            height:.36rem;
            padding-left:.5rem;
          }
          .codeInput{
            width:2.6rem;
            float:left;
          }
          .sendCode{
            width:1.9rem;
            height:.5rem;
            position:absolute;
            right:0;
            bottom:.1rem;
            font-size:.26rem;
            color:#fff;
            background-color:#f66;
            border-radius:.25rem;
            box-shadow: 0px .05rem .05rem #dcdcdc;
          }
        }
      }
      .toRegister{
        width:4.8rem;
        margin-left:..5rem;
        height:.7rem;
        background-color:#dcdcdc;
        color:#fff;
        text-align:center;
        font-size:.26rem;
        margin-top:.6rem;
        border-radius:.32rem;
        font-weight:700;
      }
    }
    
  }
  
</style>
