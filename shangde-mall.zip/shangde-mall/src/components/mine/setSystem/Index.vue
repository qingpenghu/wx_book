<template>
  <div class="order_content_mainL">
   系统设置系统设置系统设置系统设置系统设置系统设置系统设置系统设置系统设置系统设置系统设置系统设置系统设置系统设置系统设置系统设置
  </div>
</template>
<script>
import {Dialog, Toast} from 'vant'
import './index.less'
/* 系统设置 */
export default {
  name: 'sysConfig',
  data () {
    return {
      productId: '',//订单内商品的ID
    }
  },
  methods: {
    routergo: function () {
      this.$router.back(-1)
    }
	},
  mounted() {
   
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
