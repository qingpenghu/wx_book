<template>
  <div class="mainUserInfo">
    <ul class="infoBox">
      <li class="infoLis">
        <router-link to="/editorName">
          <span class="lisLabel fl">昵称</span>
          <van-icon class="fr" name="arrow" />
          <span class="lisText fr">气死你丫的</span>
        </router-link>
      </li>
      <li class="infoLis" @click="showSetSexBox">
        <span class="lisLabel fl">性别</span>
        <van-icon class="fr" name="arrow" />
        <span class="lisText fr" v-if="sexText">男</span>
        <span class="lisText fr" v-else>请选择</span>
        <van-popup v-model="setSex" class="popupSex">
          <span class="popupTitle">性别</span>
          <van-radio-group v-model="radioSex">
            <van-cell-group>
              <van-cell title="男" clickable @click="radio = '1'">
                <van-radio name="1" />
              </van-cell>
              <van-cell title="女" clickable @click="radio = '2'">
                <van-radio name="2" />
              </van-cell>
            </van-cell-group>
          </van-radio-group>
        </van-popup>
      </li>
      <li class="infoLis" @click="showSetBirthDate">
        <span class="lisLabel fl">出生日期</span>
        <van-icon class="fr" name="arrow" />
        <span class="lisText fr" v-if="birthDate">2018-06-15</span>
        <span class="lisText fr" v-else>请选择</span>
      </li>
    </ul>
    <div class="logOutBox"><span class="logOut">退出登录</span></div>
  </div>
</template>
<script>
import {Dialog, Toast} from 'vant'
import './index.less'
/* 个人中心修改 */
export default {
  name: 'userInfo',
  data () {
    return {
      setSex: false,//选择性别
      setBirthDate: false,//选择出生日期
      sexText: '',//初始化性别
      birthDate: '',//初始化出生日期
      radioSex: '1',//选择性别弹出层默认选择男
      birthDate: new Date(),//出生日期默认为当前时间
    }
  },
  methods: {
    routergo: function () {
      this.$router.back(-1)
    },
    showSetSexBox: function (){
      this.setSex = true;
    },
    showSetBirthDate: function (){
      Dialog.confirm({
        title: '日期',
        // message: '<van-datetime-picker v-model="birthDate" type="date" />'
      }).then(() => {
        // on confirm
      }).catch(() => {
        // on cancel
      });
    }
	}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
