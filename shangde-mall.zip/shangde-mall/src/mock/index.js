/* eslint-disable */
'use strict';
//require('./test');
//require('./loginIn');
//require('./shop');
//require('./hartList');
//require('./goodsDetial');
//require('./goodsCate');
//require('./commonApi');