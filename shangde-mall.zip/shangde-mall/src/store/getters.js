/* eslint-disable */
'use strict';
/**
 * [global Getters]
 * @type {Object}
 */
const Getters = {
  
};
export default Getters;
