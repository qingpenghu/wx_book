/* eslint-disable */
'use strict';
/**
 * [global State]
 * @type {Object}
 */
const State = {
};
export default State;