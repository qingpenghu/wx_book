/* eslint-disable */
'use strict';
import config from './config';
import request from './request';

const utils = {
  config,
  request,
};
export default utils;